int yylex();
int main()
{
	yylex();
}